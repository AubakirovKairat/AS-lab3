# TSN_DEMO_03_Questionnaire
Многооконная программа
![Screenshot](screenshot1.png)

![Screenshot](screenshot2.png)
