# TSN_ANDROID_DEMO_MICRO
Простейшие авторские демо-примеры Талипова С.Н. для Android Studio

**Квадратное уравнение с 2-мя разметками (TSN_DEMO_02_Quadratic):**

![Screenshot](screenshot.png)

**Многооконная программа (TSN_DEMO_03_Questionnaire):**

![Screenshot](screenshot1.png)

![Screenshot](screenshot2.png)

https://www.youtube.com/watch?v=kVbK5phEpRM

https://www.youtube.com/watch?v=ZACUmft0G6s


_Полная версия доступна официальным участникам курса Талипова С.Н._

Полная электронная версия для Android: https://play.google.com/store/apps/details?id=kz.proffix4.tsn.lectnb

Copyright (c) 2022, Talipov S.N.
All rights reserved.

